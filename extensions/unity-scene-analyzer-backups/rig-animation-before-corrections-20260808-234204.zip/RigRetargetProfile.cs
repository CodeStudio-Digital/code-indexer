using System;
using System.Collections.Generic;
using UnityEngine;

namespace Maicon.SceneAnalyzer.Modeling
{
    [Serializable]
    public sealed class RigRetargetBoneMap
    {
        public string SourcePath;
        public string DestinationPath;
        public string HumanBone;
        public Quaternion RotationOffset = Quaternion.identity;
        [Range(0f, 1f)] public float Confidence;
        public bool Enabled = true;
    }

    [CreateAssetMenu(menuName = "Asset Modeler/Rig Retarget Profile", fileName = "RigRetargetProfile")]
    public sealed class RigRetargetProfile : ScriptableObject
    {
        public string SourceHierarchyHash;
        public string DestinationHierarchyHash;
        public string SourceRigType;
        public string DestinationRigType;
        public List<RigRetargetBoneMap> Bones = new List<RigRetargetBoneMap>();
    }
}
