using System;
using System.Linq;
using NUnit.Framework;
using Unity.Collections;
using UnityEditor;
using UnityEngine;
using Maicon.SceneAnalyzer.Editor.Modeling.Rigging;
using Maicon.SceneAnalyzer.Modeling;
using Maicon.SceneAnalyzer.Editor.Mcp;

namespace Maicon.SceneAnalyzer.Editor.Modeling.Tests
{
    public sealed class RigAnimationStudioTests
    {
        private const string TempFolder = "Assets/__RigAnimationStudioTests";
        private GameObject root;
        private readonly System.Collections.Generic.List<GameObject> extraRoots = new System.Collections.Generic.List<GameObject>();

        [SetUp]
        public void SetUp()
        {
            if (!AssetDatabase.IsValidFolder(TempFolder)) AssetDatabase.CreateFolder("Assets", "__RigAnimationStudioTests");
            root = CreateCharacter(out _);
        }

        [TearDown]
        public void TearDown()
        {
            if (root != null) UnityEngine.Object.DestroyImmediate(root);
            for (int i = 0; i < extraRoots.Count; i++) if (extraRoots[i] != null) UnityEngine.Object.DestroyImmediate(extraRoots[i]);
            extraRoots.Clear();
            AssetDatabase.DeleteAsset(TempFolder);
            AnimationMode.StopAnimationMode();
        }

        [Test]
        public void InspectorAndHeatmap_PreserveMoreThanFourInfluences()
        {
            var renderer = root.GetComponentInChildren<SkinnedMeshRenderer>();
            var report = RigInspectorService.Inspect(root);
            Assert.That(report.VertexCount, Is.EqualTo(3));
            Assert.That(report.MaximumInfluences, Is.EqualTo(5));
            Assert.That(report.UnweightedVertexCount, Is.Zero);
            var heatmap = RigInspectorService.ComputeInfluenceHeatmap(renderer.sharedMesh, 0);
            Assert.That(heatmap.Length, Is.EqualTo(3));
            Assert.That(heatmap[0], Is.EqualTo(0.2f).Within(1e-5f));
        }

        [Test]
        public void Resolver_AcceptsCharacterRootRendererAndBone()
        {
            var renderer = root.GetComponentInChildren<SkinnedMeshRenderer>(); var bone = renderer.bones[2];
            Assert.That(RigTargetResolver.Resolve(root).Root, Is.EqualTo(root));
            Assert.That(RigTargetResolver.Resolve(renderer.gameObject).Root, Is.EqualTo(root));
            Assert.That(RigTargetResolver.Resolve(bone.gameObject).Root, Is.EqualTo(root));
        }

        [Test]
        public void ClipValidation_AlwaysRestoresPose()
        {
            var bone = root.transform.GetChild(0);
            bone.localPosition = new Vector3(0f, 1f, 0f);
            var clip = new AnimationClip();
            clip.SetCurve(bone.name, typeof(Transform), "m_LocalPosition.x", AnimationCurve.Linear(0f, 0f, 1f, 2f));
            var report = RigClipValidationService.Validate(root, new[] { clip }, 3);
            Assert.That(report.Clips.Count, Is.EqualTo(1));
            Assert.That(bone.localPosition, Is.EqualTo(new Vector3(0f, 1f, 0f)));
            UnityEngine.Object.DestroyImmediate(clip);
        }

        [Test]
        public void WeightPainter_RequiresEditableAssetAndNormalizesAllVertices()
        {
            var renderer = root.GetComponentInChildren<SkinnedMeshRenderer>();
            Assert.Throws<InvalidOperationException>(() => SkinWeightEditorService.ApplyRadialBrush(
                renderer, 0, Vector3.zero, new SkinWeightBrushSettings { Mode = SkinWeightPaintMode.Flood }));
            var mesh = RigAssetSafety.CreateEditableSkinCopy(renderer, TempFolder);
            var result = SkinWeightEditorService.ApplyRadialBrush(renderer, 1, Vector3.zero,
                new SkinWeightBrushSettings { Mode = SkinWeightPaintMode.Flood, Strength = 0.5f, MaximumInfluences = 8 });
            Assert.That(result.AffectedVertices, Is.EqualTo(mesh.vertexCount));
            var table = SkinWeightTable.Read(mesh);
            Assert.That(table.Vertices.All(value => Math.Abs(value.Values.Sum() - 1f) < 1e-5f), Is.True);
            Assert.That(table.Vertices.All(value => value.ContainsKey(1)), Is.True);
        }

        [Test]
        public void BindPoseAndWeightTransfer_MapCompleteSkeletonWithoutDroppingWeights()
        {
            var source = root.GetComponentInChildren<SkinnedMeshRenderer>();
            var destinationRoot = CreateCharacter(out var generatedMesh);
            extraRoots.Add(destinationRoot);
            var destination = destinationRoot.GetComponentInChildren<SkinnedMeshRenderer>();
            var editable = UnityEngine.Object.Instantiate(generatedMesh);
            AssetDatabase.CreateAsset(editable, TempFolder + "/TransferDestination.asset");
            destination.sharedMesh = editable;
            var report = SkinWeightTransferService.Transfer(source, destination);
            Assert.That(report.IsValid, Is.True);
            Assert.That(report.ExactVertexMatches, Is.EqualTo(editable.vertexCount));
            BindPoseService.Rebuild(destination);
            Assert.That(editable.bindposeCount, Is.EqualTo(destination.bones.Length));
            var table = SkinWeightTable.Read(editable);
            Assert.That(table.Vertices[0].Count, Is.EqualTo(5));
        }

        [Test]
        public void PoseLibrary_CapturesAndRestoresTransformPose()
        {
            var bone = root.transform.GetChild(0);
            bone.localRotation = Quaternion.Euler(10f, 20f, 30f);
            var pose = RigPoseLibraryService.Capture(root, "Aim");
            bone.localRotation = Quaternion.Euler(-30f, 0f, 0f);
            RigPoseLibraryService.Apply(root, pose);
            Assert.That(Quaternion.Angle(bone.localRotation, Quaternion.Euler(10f, 20f, 30f)), Is.LessThan(0.001f));
            Assert.That(pose.Transforms.Count, Is.EqualTo(root.GetComponentsInChildren<Transform>(true).Length));
        }

        [Test]
        public void ClipStudio_TrimCreatesStandaloneClipAndPreservesEvent()
        {
            var source = new AnimationClip { name = "SourceMotion", frameRate = 30f };
            source.SetCurve("Bone0", typeof(Transform), "m_LocalPosition.x", AnimationCurve.Linear(0f, 0f, 2f, 2f));
            AnimationUtility.SetAnimationEvents(source, new[] { new AnimationEvent { time = 1f, functionName = "Footstep" } });
            var output = AnimationClipStudioService.Transform(source, new AnimationClipTransformSettings
            {
                Operation = AnimationClipTransformOperation.Trim, StartTime = 0.5f, EndTime = 1.5f, OutputFolder = TempFolder,
            });
            Assert.That(output.length, Is.EqualTo(1f).Within(0.001f));
            Assert.That(AnimationUtility.GetAnimationEvents(output).Single().time, Is.EqualTo(0.5f).Within(0.001f));
            Assert.That(AssetDatabase.GetAssetPath(output), Does.EndWith(".anim"));
            UnityEngine.Object.DestroyImmediate(source);
        }

        [Test]
        public void GenericRetarget_MapsByNameAppliesPoseAndBakesClip()
        {
            var destination = CreateCharacter(out _); extraRoots.Add(destination);
            var analysis = RigRetargetAnalyzer.Analyze(root, destination, TempFolder);
            Assert.That(analysis.IsComplete, Is.True);
            var sourceBone = root.transform.GetChild(0); var destinationBone = destination.transform.GetChild(0);
            sourceBone.localRotation = Quaternion.Euler(0f, 0f, 40f);
            RigRetargetService.ApplyPose(root, destination, analysis.Profile);
            Assert.That(Quaternion.Angle(sourceBone.localRotation, destinationBone.localRotation), Is.LessThan(0.001f));
            sourceBone.localRotation = Quaternion.identity; destinationBone.localRotation = Quaternion.identity;
            var clip = new AnimationClip { name = "GenericTurn" };
            clip.SetCurve("Bone0", typeof(Transform), "m_LocalRotation.z", AnimationCurve.Linear(0f, 0f, 1f, 0.5f));
            clip.SetCurve("Bone0", typeof(Transform), "m_LocalRotation.w", AnimationCurve.Linear(0f, 1f, 1f, 0.8660254f));
            var output = RigRetargetService.RetargetClip(root, destination, analysis.Profile, clip, 10f, TempFolder);
            Assert.That(AnimationUtility.GetCurveBindings(output).Length, Is.GreaterThanOrEqualTo(4));
            Assert.That(sourceBone.localRotation, Is.EqualTo(Quaternion.identity));
            Assert.That(destinationBone.localRotation, Is.EqualTo(Quaternion.identity));
            UnityEngine.Object.DestroyImmediate(clip);
        }

        [Test]
        public void NativeTwoBoneIk_ReducesTipErrorAndBakeRestoresPose()
        {
            var chainRoot = root.transform.GetChild(0); var mid = chainRoot.GetChild(0); var tip = mid.GetChild(0);
            var binding = RigIkService.Create(root, chainRoot, mid, tip, RigIkSolverType.TwoBone);
            binding.Target.position = chainRoot.position + new Vector3(0.15f, 0.28f, 0f);
            binding.Hint.position = chainRoot.position + Vector3.forward;
            float before = Vector3.Distance(tip.position, binding.Target.position);
            NativeRigIkSolver.Solve(binding);
            float after = Vector3.Distance(tip.position, binding.Target.position);
            Assert.That(after, Is.LessThan(before));
            var originalRootRotation = chainRoot.localRotation;
            var clip = new AnimationClip { name = "IdleForIk" };
            clip.SetCurve("Bone0", typeof(Transform), "m_LocalRotation.w", AnimationCurve.Constant(0f, 1f, chainRoot.localRotation.w));
            var output = RigIkService.Bake(root, binding, clip, 10f, TempFolder);
            Assert.That(AnimationUtility.GetCurveBindings(output).Length, Is.GreaterThanOrEqualTo(8));
            Assert.That(chainRoot.localRotation, Is.EqualTo(originalRootRotation));
            UnityEngine.Object.DestroyImmediate(clip);
        }

        [Test]
        public void AutoRig_RequiresExactHashesAndProducesNormalizedEditableSkin()
        {
            var staticObject = GameObject.CreatePrimitive(PrimitiveType.Cube); staticObject.name = "StaticHumanoidCandidate";
            staticObject.transform.localScale = new Vector3(1.2f, 2.2f, 0.6f); extraRoots.Add(staticObject);
            var proposal = HumanoidAutoRigAnalyzer.Analyze(staticObject);
            Assert.That(proposal.Landmarks.Count, Is.EqualTo(19));
            Assert.Throws<InvalidOperationException>(() => HumanoidAutoRigService.Apply(proposal, "wrong", proposal.MeshHash, TempFolder));
            var result = HumanoidAutoRigService.Apply(proposal, proposal.ProposalHash, proposal.MeshHash, TempFolder);
            Assert.That(result.BoneCount, Is.EqualTo(19));
            Assert.That(RigAssetSafety.IsEditableStandaloneMesh(result.Renderer.sharedMesh), Is.True);
            var table = SkinWeightTable.Read(result.Renderer.sharedMesh);
            Assert.That(table.Vertices.All(value => Math.Abs(value.Values.Sum() - 1f) < 1e-5f), Is.True);
            Assert.That(RigInspectorService.Inspect(result.Renderer.gameObject).IsValid, Is.True);
        }

        [Test]
        public void RigMcpContracts_RegisterAllNineteenTools()
        {
            var registry = new McpToolRegistry();
            registry.RegisterRange(new IMcpTool[]
            {
                new RigInspectTool(), new RigValidateClipsTool(), new RigCreateEditableSkinTool(), new RigApplyWeightOperationTool(),
                new RigRebuildBindPosesTool(), new RigTransferWeightsTool(), new RigEditSkeletonTool(), new AnimationCapturePoseTool(),
                new AnimationApplyPoseTool(), new AnimationTransformClipTool(), new RigAnalyzeRetargetTool(), new RigApplyRetargetPoseTool(),
                new RigRetargetClipTool(), new RigCreateIkTool(), new RigPreviewIkTool(), new RigBakeIkClipTool(),
                new RigAnalyzeAutoRigTool(), new RigPreviewAutoRigTool(), new RigApplyAutoRigTool(),
            });
            Assert.That(registry.Count, Is.EqualTo(19));
            Assert.That(registry.All.Count(tool => tool.IsWrite), Is.EqualTo(15));
        }

        private static GameObject CreateCharacter(out Mesh mesh)
        {
            var root = new GameObject("RigTestCharacter");
            var bones = new Transform[5];
            for (int i = 0; i < bones.Length; i++)
            {
                var bone = new GameObject("Bone" + i).transform;
                bone.SetParent(i == 0 ? root.transform : bones[i - 1], false);
                bone.localPosition = new Vector3(0f, i == 0 ? 0f : 0.2f, 0f);
                bones[i] = bone;
            }
            var skinObject = new GameObject("Skin");
            skinObject.transform.SetParent(root.transform, false);
            var renderer = skinObject.AddComponent<SkinnedMeshRenderer>();
            mesh = new Mesh { name = "RigTestMesh" };
            mesh.vertices = new[] { new Vector3(-0.5f, 0f, 0f), new Vector3(0.5f, 0f, 0f), new Vector3(0f, 1f, 0f) };
            mesh.triangles = new[] { 0, 1, 2 };
            mesh.bindposes = bones.Select(bone => bone.worldToLocalMatrix * skinObject.transform.localToWorldMatrix).ToArray();
            var counts = new byte[] { 5, 1, 1 };
            var weights = new[]
            {
                new BoneWeight1 { boneIndex = 0, weight = .2f }, new BoneWeight1 { boneIndex = 1, weight = .2f },
                new BoneWeight1 { boneIndex = 2, weight = .2f }, new BoneWeight1 { boneIndex = 3, weight = .2f },
                new BoneWeight1 { boneIndex = 4, weight = .2f }, new BoneWeight1 { boneIndex = 0, weight = 1f },
                new BoneWeight1 { boneIndex = 0, weight = 1f },
            };
            using (var nativeCounts = new NativeArray<byte>(counts, Allocator.Temp))
            using (var nativeWeights = new NativeArray<BoneWeight1>(weights, Allocator.Temp)) mesh.SetBoneWeights(nativeCounts, nativeWeights);
            mesh.RecalculateNormals(); mesh.RecalculateBounds();
            renderer.sharedMesh = mesh; renderer.bones = bones; renderer.rootBone = bones[0];
            return root;
        }
    }
}
