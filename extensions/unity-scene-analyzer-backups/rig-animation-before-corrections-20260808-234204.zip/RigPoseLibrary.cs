using System;
using System.Collections.Generic;
using UnityEngine;

namespace Maicon.SceneAnalyzer.Modeling
{
    [Serializable]
    public sealed class RigTransformPose
    {
        public string Path;
        public Vector3 LocalPosition;
        public Quaternion LocalRotation = Quaternion.identity;
        public Vector3 LocalScale = Vector3.one;
    }

    [Serializable]
    public sealed class RigPoseEntry
    {
        public string Id;
        public string Name;
        public string RigType;
        public string HierarchyHash;
        public string CreatedUtc;
        public List<RigTransformPose> Transforms = new List<RigTransformPose>();
        public Vector3 HumanBodyPosition;
        public Quaternion HumanBodyRotation = Quaternion.identity;
        public float[] HumanMuscles = Array.Empty<float>();
    }

    [CreateAssetMenu(menuName = "Asset Modeler/Rig Pose Library", fileName = "RigPoseLibrary")]
    public sealed class RigPoseLibrary : ScriptableObject
    {
        [SerializeField] private List<RigPoseEntry> poses = new List<RigPoseEntry>();
        public IReadOnlyList<RigPoseEntry> Poses => poses;
        public void Add(RigPoseEntry pose) { if (pose != null) poses.Add(pose); }
        public bool Remove(string id) => poses.RemoveAll(value => value != null && value.Id == id) > 0;
        public RigPoseEntry Find(string id) => poses.Find(value => value != null && value.Id == id);
    }
}
