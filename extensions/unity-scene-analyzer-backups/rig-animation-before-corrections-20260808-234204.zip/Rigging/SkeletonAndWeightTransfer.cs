using System;
using System.Collections.Generic;
using System.Linq;
using UnityEditor;
using UnityEngine;

namespace Maicon.SceneAnalyzer.Editor.Modeling.Rigging
{
    public sealed class WeightTransferReport
    {
        public int VertexCount;
        public int ExactVertexMatches;
        public int SurfaceMatches;
        public int UnmappedBoneCount;
        public float MaximumDistance;
        public float MeanDistance;
        public bool IsValid => VertexCount > 0 && ExactVertexMatches + SurfaceMatches == VertexCount && UnmappedBoneCount == 0;
    }

    public static class SkeletonEditorService
    {
        public static Transform CreateBone(Transform parent, string name, Vector3 localPosition)
        {
            if (parent == null) throw new ArgumentNullException(nameof(parent));
            var gameObject = new GameObject(string.IsNullOrWhiteSpace(name) ? "Bone" : name.Trim());
            Undo.RegisterCreatedObjectUndo(gameObject, "Create bone");
            Undo.SetTransformParent(gameObject.transform, parent, "Parent bone");
            gameObject.transform.localPosition = localPosition;
            gameObject.transform.localRotation = Quaternion.identity;
            return gameObject.transform;
        }

        public static Transform DuplicateBone(Transform source, bool includeChildren)
        {
            if (source == null) throw new ArgumentNullException(nameof(source));
            var clone = UnityEngine.Object.Instantiate(source.gameObject, source.parent, false);
            clone.name = source.name + "_Copy";
            if (!includeChildren)
                while (clone.transform.childCount > 0) UnityEngine.Object.DestroyImmediate(clone.transform.GetChild(0).gameObject);
            Undo.RegisterCreatedObjectUndo(clone, "Duplicate bone");
            return clone.transform;
        }

        public static void RenameBone(Transform bone, string name)
        {
            if (bone == null) throw new ArgumentNullException(nameof(bone));
            if (string.IsNullOrWhiteSpace(name)) throw new ArgumentException("BONE_NAME_REQUIRED", nameof(name));
            Undo.RecordObject(bone.gameObject, "Rename bone"); bone.name = name.Trim(); EditorUtility.SetDirty(bone.gameObject);
        }

        public static void ReparentBone(Transform bone, Transform parent, bool preserveWorldPose = true)
        {
            if (bone == null || parent == null) throw new ArgumentNullException();
            if (parent == bone || parent.IsChildOf(bone)) throw new InvalidOperationException("BONE_PARENT_CYCLE: a bone cannot be parented to itself or its descendant.");
            Undo.SetTransformParent(bone, parent, "Reparent bone");
            if (!preserveWorldPose) { Undo.RecordObject(bone, "Reset reparented bone"); bone.localPosition = Vector3.zero; bone.localRotation = Quaternion.identity; }
        }

        public static void MoveBone(Transform bone, Vector3 localPosition, Quaternion localRotation)
        {
            if (bone == null) throw new ArgumentNullException(nameof(bone));
            Undo.RecordObject(bone, "Move bone"); bone.localPosition = localPosition; bone.localRotation = localRotation;
        }

        public static void SetRootBone(SkinnedMeshRenderer renderer, Transform rootBone)
        {
            if (renderer == null) throw new ArgumentNullException(nameof(renderer));
            Undo.RecordObject(renderer, "Set root bone"); renderer.rootBone = rootBone; EditorUtility.SetDirty(renderer);
        }
    }

    public static class BindPoseService
    {
        public static Matrix4x4[] Calculate(SkinnedMeshRenderer renderer)
        {
            if (renderer == null) throw new ArgumentNullException(nameof(renderer));
            return (renderer.bones ?? Array.Empty<Transform>()).Select(bone => bone != null
                ? bone.worldToLocalMatrix * renderer.transform.localToWorldMatrix
                : Matrix4x4.identity).ToArray();
        }

        public static void Rebuild(SkinnedMeshRenderer renderer)
        {
            if (renderer == null || renderer.sharedMesh == null) throw new ArgumentNullException(nameof(renderer));
            RigAssetSafety.RequireEditable(renderer.sharedMesh);
            if ((renderer.bones ?? Array.Empty<Transform>()).Any(bone => bone == null))
                throw new InvalidOperationException("NULL_BONE: all renderer bones must resolve before rebuilding bind poses.");
            Undo.RegisterCompleteObjectUndo(renderer.sharedMesh, "Rebuild bind poses");
            renderer.sharedMesh.bindposes = Calculate(renderer);
            EditorUtility.SetDirty(renderer.sharedMesh);
        }
    }

    public static class SkinWeightTransferService
    {
        public static WeightTransferReport Transfer(SkinnedMeshRenderer source, SkinnedMeshRenderer destination, float maximumDistance = float.PositiveInfinity)
        {
            if (source == null || source.sharedMesh == null) throw new ArgumentNullException(nameof(source));
            if (destination == null || destination.sharedMesh == null) throw new ArgumentNullException(nameof(destination));
            RigAssetSafety.RequireEditable(destination.sharedMesh);
            var sourceBones = source.bones ?? Array.Empty<Transform>();
            if ((destination.bones ?? Array.Empty<Transform>()).Length == 0)
            {
                Undo.RecordObject(destination, "Assign transferred skeleton");
                destination.bones = sourceBones; destination.rootBone = source.rootBone;
            }
            var destinationBones = destination.bones ?? Array.Empty<Transform>();
            var boneMap = BuildBoneMap(sourceBones, destinationBones);
            var usedBones = SkinWeightTable.Read(source.sharedMesh).Vertices.SelectMany(weights => weights.Keys).Distinct().ToArray();
            var unmapped = usedBones.Where(index => index < 0 || index >= boneMap.Length || boneMap[index] < 0).ToArray();
            if (unmapped.Length > 0) throw new InvalidOperationException("WEIGHT_TRANSFER_UNMAPPED_BONES: " + string.Join(",", unmapped));

            var sourceTable = SkinWeightTable.Read(source.sharedMesh);
            var destinationTable = new SkinWeightTable(destination.sharedMesh.vertexCount);
            var sourceVertices = source.sharedMesh.vertices;
            var destinationVertices = destination.sharedMesh.vertices;
            var sourceTriangles = source.sharedMesh.triangles;
            var report = new WeightTransferReport { VertexCount = destinationVertices.Length };
            double distanceSum = 0d;
            bool exactTopology = sourceVertices.Length == destinationVertices.Length
                && source.sharedMesh.triangles.SequenceEqual(destination.sharedMesh.triangles);
            for (int vertex = 0; vertex < destinationVertices.Length; vertex++)
            {
                Vector3 world = destination.transform.TransformPoint(destinationVertices[vertex]);
                if (exactTopology)
                {
                    CopyWeights(sourceTable.Vertices[vertex], destinationTable.Vertices[vertex], boneMap, 1f);
                    float distance = Vector3.Distance(world, source.transform.TransformPoint(sourceVertices[vertex]));
                    report.MaximumDistance = Mathf.Max(report.MaximumDistance, distance); distanceSum += distance; report.ExactVertexMatches++;
                    continue;
                }
                FindClosestSurface(source, sourceVertices, sourceTriangles, world, out int a, out int b, out int c, out Vector3 barycentric, out float surfaceDistance);
                if (a < 0 || surfaceDistance > maximumDistance) throw new InvalidOperationException($"WEIGHT_TRANSFER_COVERAGE_FAILED: vertex {vertex} has no source surface within {maximumDistance:R}.");
                CopyWeights(sourceTable.Vertices[a], destinationTable.Vertices[vertex], boneMap, barycentric.x);
                CopyWeights(sourceTable.Vertices[b], destinationTable.Vertices[vertex], boneMap, barycentric.y);
                CopyWeights(sourceTable.Vertices[c], destinationTable.Vertices[vertex], boneMap, barycentric.z);
                report.MaximumDistance = Mathf.Max(report.MaximumDistance, surfaceDistance); distanceSum += surfaceDistance; report.SurfaceMatches++;
            }
            for (int vertex = 0; vertex < destinationTable.Vertices.Count; vertex++)
                destinationTable.NormalizeAndLimit(vertex, 16, 1e-6f);
            Undo.RegisterCompleteObjectUndo(destination.sharedMesh, "Transfer skin weights");
            destinationTable.Write(destination.sharedMesh);
            destination.sharedMesh.bindposes = BindPoseService.Calculate(destination);
            EditorUtility.SetDirty(destination.sharedMesh);
            report.MeanDistance = report.VertexCount > 0 ? (float)(distanceSum / report.VertexCount) : 0f;
            return report;
        }

        private static int[] BuildBoneMap(Transform[] source, Transform[] destination)
        {
            var map = Enumerable.Repeat(-1, source.Length).ToArray();
            for (int i = 0; i < source.Length; i++)
            {
                if (source[i] == null) continue;
                for (int j = 0; j < destination.Length; j++) if (source[i] == destination[j]) { map[i] = j; break; }
                if (map[i] >= 0) continue;
                string name = Normalize(source[i].name);
                var matches = Enumerable.Range(0, destination.Length).Where(j => destination[j] != null && Normalize(destination[j].name) == name).ToArray();
                if (matches.Length == 1) map[i] = matches[0];
            }
            return map;
        }

        private static string Normalize(string value) => new string((value ?? string.Empty).Where(char.IsLetterOrDigit).Select(char.ToLowerInvariant).ToArray())
            .Replace("left", "l").Replace("right", "r");

        private static void CopyWeights(Dictionary<int, float> source, Dictionary<int, float> destination, int[] map, float multiplier)
        {
            foreach (var pair in source)
            {
                int bone = map[pair.Key]; destination.TryGetValue(bone, out float current); destination[bone] = current + pair.Value * multiplier;
            }
        }

        private static void FindClosestSurface(SkinnedMeshRenderer renderer, Vector3[] vertices, int[] triangles, Vector3 world,
            out int bestA, out int bestB, out int bestC, out Vector3 bestBarycentric, out float bestDistance)
        {
            bestA = bestB = bestC = -1; bestBarycentric = Vector3.zero; bestDistance = float.PositiveInfinity;
            Vector3 local = renderer.transform.InverseTransformPoint(world);
            for (int i = 0; i < triangles.Length; i += 3)
            {
                int a = triangles[i], b = triangles[i + 1], c = triangles[i + 2];
                Vector3 barycentric = ClosestBarycentric(local, vertices[a], vertices[b], vertices[c]);
                Vector3 point = vertices[a] * barycentric.x + vertices[b] * barycentric.y + vertices[c] * barycentric.z;
                float distance = Vector3.Distance(world, renderer.transform.TransformPoint(point));
                if (distance >= bestDistance) continue;
                bestDistance = distance; bestA = a; bestB = b; bestC = c; bestBarycentric = barycentric;
            }
        }

        private static Vector3 ClosestBarycentric(Vector3 p, Vector3 a, Vector3 b, Vector3 c)
        {
            var ab = b - a; var ac = c - a; var ap = p - a;
            float d1 = Vector3.Dot(ab, ap), d2 = Vector3.Dot(ac, ap); if (d1 <= 0f && d2 <= 0f) return new Vector3(1f, 0f, 0f);
            var bp = p - b; float d3 = Vector3.Dot(ab, bp), d4 = Vector3.Dot(ac, bp); if (d3 >= 0f && d4 <= d3) return new Vector3(0f, 1f, 0f);
            float vc = d1 * d4 - d3 * d2; if (vc <= 0f && d1 >= 0f && d3 <= 0f) { float v = d1 / (d1 - d3); return new Vector3(1f - v, v, 0f); }
            var cp = p - c; float d5 = Vector3.Dot(ab, cp), d6 = Vector3.Dot(ac, cp); if (d6 >= 0f && d5 <= d6) return new Vector3(0f, 0f, 1f);
            float vb = d5 * d2 - d1 * d6; if (vb <= 0f && d2 >= 0f && d6 <= 0f) { float w = d2 / (d2 - d6); return new Vector3(1f - w, 0f, w); }
            float va = d3 * d6 - d5 * d4; if (va <= 0f && d4 - d3 >= 0f && d5 - d6 >= 0f) { float w = (d4 - d3) / ((d4 - d3) + (d5 - d6)); return new Vector3(0f, 1f - w, w); }
            float inverse = 1f / (va + vb + vc); float v2 = vb * inverse, w2 = vc * inverse; return new Vector3(1f - v2 - w2, v2, w2);
        }
    }
}
