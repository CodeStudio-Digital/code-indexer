using System;
using System.Collections.Generic;
using System.Linq;
using UnityEditor;
using UnityEngine;
using Maicon.SceneAnalyzer.Editor.Modeling.Assets;
using Maicon.SceneAnalyzer.Modeling;

namespace Maicon.SceneAnalyzer.Editor.Modeling.Rigging
{
    public enum AnimationClipTransformOperation { Duplicate, Trim, ScaleTime, Reverse, LoopClosure, RemoveRootMotion }

    [Serializable]
    public sealed class AnimationClipTransformSettings
    {
        public AnimationClipTransformOperation Operation;
        public float StartTime;
        public float EndTime = 1f;
        public float TimeScale = 1f;
        public string OutputFolder = "Assets/AssetModeler/Rigging/Clips";
    }

    public static class RigPoseLibraryService
    {
        public static RigPoseEntry Capture(GameObject selected, string name)
        {
            var context = RigTargetResolver.Resolve(selected);
            if (context.Root == null) throw new InvalidOperationException("RIG_TARGET_INVALID");
            var entry = new RigPoseEntry
            {
                Id = Guid.NewGuid().ToString("N"), Name = string.IsNullOrWhiteSpace(name) ? "Pose" : name.Trim(),
                RigType = context.RigType, HierarchyHash = context.HierarchyHash, CreatedUtc = DateTime.UtcNow.ToString("O"),
            };
            var transforms = context.Root.GetComponentsInChildren<Transform>(true);
            for (int i = 0; i < transforms.Length; i++)
            {
                var value = transforms[i];
                entry.Transforms.Add(new RigTransformPose
                {
                    Path = RigTargetResolver.RelativePath(value, context.Root.transform), LocalPosition = value.localPosition,
                    LocalRotation = value.localRotation, LocalScale = value.localScale,
                });
            }
            if (context.Animator != null && context.Animator.avatar != null && context.Animator.avatar.isHuman)
            {
                var human = new HumanPose();
                using (var handler = new HumanPoseHandler(context.Animator.avatar, context.Animator.transform))
                {
                    handler.GetHumanPose(ref human);
                    entry.HumanBodyPosition = human.bodyPosition; entry.HumanBodyRotation = human.bodyRotation;
                    entry.HumanMuscles = human.muscles != null ? (float[])human.muscles.Clone() : Array.Empty<float>();
                }
            }
            return entry;
        }

        public static void Add(RigPoseLibrary library, RigPoseEntry entry)
        {
            if (library == null || entry == null) throw new ArgumentNullException();
            Undo.RecordObject(library, "Capture rig pose"); library.Add(entry); EditorUtility.SetDirty(library);
        }

        public static void Apply(GameObject selected, RigPoseEntry entry)
        {
            if (entry == null) throw new ArgumentNullException(nameof(entry));
            var context = RigTargetResolver.Resolve(selected);
            if (context.Root == null) throw new InvalidOperationException("RIG_TARGET_INVALID");
            if (!string.Equals(context.HierarchyHash, entry.HierarchyHash, StringComparison.Ordinal))
                throw new InvalidOperationException("POSE_HIERARCHY_CHANGED: the pose belongs to a different hierarchy revision.");
            var transforms = context.Root.GetComponentsInChildren<Transform>(true);
            Undo.RecordObjects(transforms.Cast<UnityEngine.Object>().ToArray(), "Apply rig pose");
            if (entry.HumanMuscles != null && entry.HumanMuscles.Length > 0 && context.Animator != null && context.Animator.avatar != null && context.Animator.avatar.isHuman)
            {
                var human = new HumanPose { bodyPosition = entry.HumanBodyPosition, bodyRotation = entry.HumanBodyRotation, muscles = (float[])entry.HumanMuscles.Clone() };
                using (var handler = new HumanPoseHandler(context.Animator.avatar, context.Animator.transform)) handler.SetHumanPose(ref human);
            }
            for (int i = 0; i < entry.Transforms.Count; i++)
            {
                var pose = entry.Transforms[i];
                var transform = string.IsNullOrEmpty(pose.Path) ? context.Root.transform : context.Root.transform.Find(pose.Path);
                if (transform == null) throw new InvalidOperationException("POSE_BONE_MISSING: " + pose.Path);
                transform.localPosition = pose.LocalPosition; transform.localRotation = pose.LocalRotation; transform.localScale = pose.LocalScale;
            }
        }

        public static RigPoseLibrary CreateLibrary(string outputFolder, string name = "RigPoseLibrary")
        {
            var folder = AssetModelerAssetPaths.ValidateAndEnsureFolder(string.IsNullOrWhiteSpace(outputFolder) ? "Assets/AssetModeler/Rigging/Poses" : outputFolder);
            var library = ScriptableObject.CreateInstance<RigPoseLibrary>(); library.name = name;
            AssetDatabase.CreateAsset(library, AssetModelerAssetPaths.UniqueAssetPath(folder, name, ".asset")); AssetDatabase.SaveAssets();
            return library;
        }
    }

    public static class AnimationClipStudioService
    {
        public static AnimationClip Transform(AnimationClip source, AnimationClipTransformSettings settings)
        {
            if (source == null) throw new ArgumentNullException(nameof(source));
            settings = settings ?? new AnimationClipTransformSettings();
            var output = new AnimationClip { name = source.name + "_" + settings.Operation, frameRate = source.frameRate, wrapMode = source.wrapMode, legacy = source.legacy };
            float start = settings.Operation == AnimationClipTransformOperation.Trim ? Mathf.Clamp(settings.StartTime, 0f, source.length) : 0f;
            float end = settings.Operation == AnimationClipTransformOperation.Trim ? Mathf.Clamp(settings.EndTime, start, source.length) : source.length;
            float scale = settings.Operation == AnimationClipTransformOperation.ScaleTime ? Mathf.Max(1e-4f, settings.TimeScale) : 1f;
            var bindings = AnimationUtility.GetCurveBindings(source);
            for (int i = 0; i < bindings.Length; i++)
            {
                var binding = bindings[i];
                if (settings.Operation == AnimationClipTransformOperation.RemoveRootMotion && IsRootMotion(binding)) continue;
                var curve = AnimationUtility.GetEditorCurve(source, binding);
                AnimationUtility.SetEditorCurve(output, binding, TransformCurve(curve, settings.Operation, start, end, scale));
            }
            var objectBindings = AnimationUtility.GetObjectReferenceCurveBindings(source);
            for (int i = 0; i < objectBindings.Length; i++)
            {
                var binding = objectBindings[i];
                if (settings.Operation == AnimationClipTransformOperation.RemoveRootMotion && IsRootMotion(binding)) continue;
                var keys = AnimationUtility.GetObjectReferenceCurve(source, binding);
                AnimationUtility.SetObjectReferenceCurve(output, binding, TransformObjectKeys(keys, settings.Operation, start, end, scale));
            }
            var events = TransformEvents(AnimationUtility.GetAnimationEvents(source), settings.Operation, start, end, scale);
            var folder = AssetModelerAssetPaths.ValidateAndEnsureFolder(string.IsNullOrWhiteSpace(settings.OutputFolder) ? "Assets/AssetModeler/Rigging/Clips" : settings.OutputFolder);
            AssetDatabase.CreateAsset(output, AssetModelerAssetPaths.UniqueAssetPath(folder, output.name, ".anim"));
            AnimationUtility.SetAnimationEvents(output, events);
            AssetDatabase.SaveAssets(); return output;
        }

        private static AnimationCurve TransformCurve(AnimationCurve source, AnimationClipTransformOperation operation, float start, float end, float scale)
        {
            var keys = new List<Keyframe>();
            if (operation == AnimationClipTransformOperation.Trim)
            {
                keys.Add(new Keyframe(0f, source.Evaluate(start)));
                foreach (var original in source.keys) if (original.time > start && original.time < end) { var key = original; key.time -= start; keys.Add(key); }
                keys.Add(new Keyframe(end - start, source.Evaluate(end)));
            }
            else
            {
                foreach (var original in source.keys)
                {
                    var key = original;
                    if (operation == AnimationClipTransformOperation.ScaleTime) key.time *= scale;
                    else if (operation == AnimationClipTransformOperation.Reverse) { key.time = source.keys.Last().time - key.time; float tangent = key.inTangent; key.inTangent = -key.outTangent; key.outTangent = -tangent; }
                    keys.Add(key);
                }
                if (operation == AnimationClipTransformOperation.LoopClosure && keys.Count > 1) { var key = keys[keys.Count - 1]; key.value = keys[0].value; keys[keys.Count - 1] = key; }
            }
            keys.Sort((left, right) => left.time.CompareTo(right.time));
            var curve = new AnimationCurve(keys.ToArray()) { preWrapMode = source.preWrapMode, postWrapMode = source.postWrapMode };
            return curve;
        }

        private static ObjectReferenceKeyframe[] TransformObjectKeys(ObjectReferenceKeyframe[] source, AnimationClipTransformOperation operation, float start, float end, float scale)
        {
            var result = new List<ObjectReferenceKeyframe>(); float length = source.Length > 0 ? source.Max(key => key.time) : 0f;
            foreach (var original in source)
            {
                var key = original;
                if (operation == AnimationClipTransformOperation.Trim) { if (key.time < start || key.time > end) continue; key.time -= start; }
                else if (operation == AnimationClipTransformOperation.ScaleTime) key.time *= scale;
                else if (operation == AnimationClipTransformOperation.Reverse) key.time = length - key.time;
                result.Add(key);
            }
            return result.OrderBy(key => key.time).ToArray();
        }

        private static AnimationEvent[] TransformEvents(AnimationEvent[] source, AnimationClipTransformOperation operation, float start, float end, float scale)
        {
            var result = new List<AnimationEvent>(); float length = source.Length > 0 ? source.Max(value => value.time) : 0f;
            foreach (var original in source)
            {
                if (operation == AnimationClipTransformOperation.Trim && (original.time < start || original.time > end)) continue;
                var copy = new AnimationEvent { functionName = original.functionName, stringParameter = original.stringParameter, floatParameter = original.floatParameter, intParameter = original.intParameter, objectReferenceParameter = original.objectReferenceParameter, messageOptions = original.messageOptions };
                copy.time = operation == AnimationClipTransformOperation.Trim ? original.time - start
                    : operation == AnimationClipTransformOperation.ScaleTime ? original.time * scale
                    : operation == AnimationClipTransformOperation.Reverse ? length - original.time : original.time;
                result.Add(copy);
            }
            return result.OrderBy(value => value.time).ToArray();
        }

        private static bool IsRootMotion(EditorCurveBinding binding)
            => string.IsNullOrEmpty(binding.path) && (binding.propertyName.StartsWith("RootT", StringComparison.Ordinal)
                || binding.propertyName.StartsWith("RootQ", StringComparison.Ordinal)
                || binding.propertyName.StartsWith("m_LocalPosition", StringComparison.Ordinal)
                || binding.propertyName.StartsWith("m_LocalRotation", StringComparison.Ordinal));
    }
}
