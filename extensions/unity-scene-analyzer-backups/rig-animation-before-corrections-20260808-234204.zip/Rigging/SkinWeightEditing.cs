using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using Unity.Collections;
using UnityEditor;
using UnityEngine;
using Maicon.SceneAnalyzer.Editor.Modeling.Assets;

namespace Maicon.SceneAnalyzer.Editor.Modeling.Rigging
{
    public enum SkinWeightPaintMode { Replace, Add, Subtract, Smooth, Normalize, Prune, Flood }

    [Serializable]
    public sealed class SkinWeightBrushSettings
    {
        public SkinWeightPaintMode Mode = SkinWeightPaintMode.Replace;
        public float Radius = 0.08f;
        public float Strength = 0.25f;
        public float Falloff = 1f;
        public int MaximumInfluences = 8;
        public float PruneThreshold = 0.001f;
        public bool MirrorX;
        public bool FrontFacesOnly = true;
    }

    public sealed class SkinWeightOperationResult
    {
        public int AffectedVertices;
        public int PrunedInfluences;
        public int MaximumInfluences;
        public string MeshAssetPath;
    }

    public static class RigAssetSafety
    {
        public static bool IsEditableStandaloneMesh(Mesh mesh)
        {
            if (mesh == null) return false;
            string path = AssetDatabase.GetAssetPath(mesh);
            return path.StartsWith("Assets/", StringComparison.OrdinalIgnoreCase)
                && string.Equals(Path.GetExtension(path), ".asset", StringComparison.OrdinalIgnoreCase)
                && AssetDatabase.LoadMainAssetAtPath(path) == mesh;
        }

        public static Mesh CreateEditableSkinCopy(SkinnedMeshRenderer renderer, string outputFolder = null)
        {
            if (renderer == null || renderer.sharedMesh == null) throw new ArgumentNullException(nameof(renderer));
            var folder = AssetModelerAssetPaths.ValidateAndEnsureFolder(string.IsNullOrWhiteSpace(outputFolder)
                ? $"{AssetModelerAssetPaths.DefaultRoot}/Rigging/Skins"
                : outputFolder);
            var copy = UnityEngine.Object.Instantiate(renderer.sharedMesh);
            copy.name = renderer.sharedMesh.name + "_SkinEditable";
            string path = AssetModelerAssetPaths.UniqueAssetPath(folder, copy.name, ".asset");
            AssetDatabase.CreateAsset(copy, path);
            Undo.RecordObject(renderer, "Assign editable skin mesh");
            renderer.sharedMesh = copy;
            EditorUtility.SetDirty(renderer);
            AssetDatabase.SaveAssets();
            return copy;
        }

        public static void RequireEditable(Mesh mesh)
        {
            if (!IsEditableStandaloneMesh(mesh))
                throw new InvalidOperationException("EDITABLE_SKIN_REQUIRED: create an editable .asset skin copy before changing weights.");
        }
    }

    public sealed class SkinWeightTable
    {
        public readonly List<Dictionary<int, float>> Vertices;
        public SkinWeightTable(int vertexCount)
        {
            Vertices = new List<Dictionary<int, float>>(vertexCount);
            for (int i = 0; i < vertexCount; i++) Vertices.Add(new Dictionary<int, float>());
        }

        public static SkinWeightTable Read(Mesh mesh)
        {
            var table = new SkinWeightTable(mesh.vertexCount);
            using (var counts = mesh.GetBonesPerVertex())
            using (var weights = mesh.GetAllBoneWeights())
            {
                int offset = 0;
                for (int vertex = 0; vertex < counts.Length; vertex++)
                {
                    int count = counts[vertex];
                    for (int i = 0; i < count && offset + i < weights.Length; i++)
                    {
                        var value = weights[offset + i];
                        if (value.weight > 0f) table.Vertices[vertex][value.boneIndex] = value.weight;
                    }
                    offset += count;
                }
            }
            return table;
        }

        public int NormalizeAndLimit(int vertex, int maximumInfluences, float pruneThreshold)
        {
            var weights = Vertices[vertex];
            int before = weights.Count;
            foreach (var key in weights.Where(pair => !Finite(pair.Value) || pair.Value <= pruneThreshold).Select(pair => pair.Key).ToArray()) weights.Remove(key);
            var ordered = weights.OrderByDescending(pair => pair.Value).ThenBy(pair => pair.Key).ToArray();
            weights.Clear();
            int keep = Mathf.Clamp(maximumInfluences, 1, byte.MaxValue);
            float sum = ordered.Take(keep).Sum(pair => Mathf.Max(0f, pair.Value));
            if (sum > 1e-12f)
                for (int i = 0; i < Mathf.Min(keep, ordered.Length); i++) weights[ordered[i].Key] = Mathf.Max(0f, ordered[i].Value) / sum;
            return before - weights.Count;
        }

        public void Write(Mesh mesh)
        {
            var counts = new byte[Vertices.Count];
            var output = new List<BoneWeight1>();
            for (int vertex = 0; vertex < Vertices.Count; vertex++)
            {
                var ordered = Vertices[vertex].OrderByDescending(pair => pair.Value).ThenBy(pair => pair.Key).Take(byte.MaxValue).ToArray();
                counts[vertex] = (byte)ordered.Length;
                for (int i = 0; i < ordered.Length; i++) output.Add(new BoneWeight1 { boneIndex = ordered[i].Key, weight = ordered[i].Value });
            }
            using (var nativeCounts = new NativeArray<byte>(counts, Allocator.Temp))
            using (var nativeWeights = new NativeArray<BoneWeight1>(output.ToArray(), Allocator.Temp))
                mesh.SetBoneWeights(nativeCounts, nativeWeights);
        }

        private static bool Finite(float value) => !float.IsNaN(value) && !float.IsInfinity(value);
    }

    public static class SkinWeightEditorService
    {
        public static SkinWeightOperationResult ApplyRadialBrush(
            SkinnedMeshRenderer renderer,
            int boneIndex,
            Vector3 localCenter,
            SkinWeightBrushSettings settings,
            ISet<int> lockedBones = null,
            ISet<int> lockedVertices = null,
            IReadOnlyList<Vector3> brushPositions = null)
        {
            if (renderer == null || renderer.sharedMesh == null) throw new ArgumentNullException(nameof(renderer));
            if (boneIndex < 0 || boneIndex >= renderer.bones.Length) throw new ArgumentOutOfRangeException(nameof(boneIndex));
            settings = settings ?? new SkinWeightBrushSettings();
            var mesh = renderer.sharedMesh;
            RigAssetSafety.RequireEditable(mesh);
            Undo.RegisterCompleteObjectUndo(mesh, "Paint skin weights");
            var table = SkinWeightTable.Read(mesh);
            var positions = brushPositions != null && brushPositions.Count == mesh.vertexCount ? brushPositions : mesh.vertices;
            var affected = new List<int>();
            float radius = Mathf.Max(settings.Radius, 1e-6f);
            for (int vertex = 0; vertex < positions.Count; vertex++)
            {
                if (lockedVertices != null && lockedVertices.Contains(vertex)) continue;
                float distance = Vector3.Distance(positions[vertex], localCenter);
                if (settings.Mode != SkinWeightPaintMode.Flood && distance > radius) continue;
                float normalized = settings.Mode == SkinWeightPaintMode.Flood ? 1f : 1f - distance / radius;
                float amount = Mathf.Clamp01(settings.Strength) * Mathf.Pow(Mathf.Clamp01(normalized), Mathf.Max(0.01f, settings.Falloff));
                if (Apply(table, mesh, vertex, boneIndex, amount, settings, lockedBones)) affected.Add(vertex);
            }
            if (settings.MirrorX && affected.Count > 0)
                Mirror(positions, mesh.bounds, table, affected, boneIndex, MirroredBone(renderer, boneIndex), settings, lockedBones, lockedVertices);
            int pruned = 0;
            int maximum = 0;
            for (int vertex = 0; vertex < table.Vertices.Count; vertex++)
            {
                EnsureFallback(table.Vertices[vertex], boneIndex, lockedBones);
                pruned += table.NormalizeAndLimit(vertex, settings.MaximumInfluences, settings.PruneThreshold);
                maximum = Mathf.Max(maximum, table.Vertices[vertex].Count);
            }
            table.Write(mesh);
            EditorUtility.SetDirty(mesh);
            return new SkinWeightOperationResult
            {
                AffectedVertices = affected.Count,
                PrunedInfluences = pruned,
                MaximumInfluences = maximum,
                MeshAssetPath = AssetDatabase.GetAssetPath(mesh),
            };
        }

        public static SkinWeightOperationResult NormalizeAll(SkinnedMeshRenderer renderer, int maximumInfluences = 8, float pruneThreshold = 0.001f)
        {
            return ApplyRadialBrush(renderer, 0, Vector3.zero, new SkinWeightBrushSettings
            {
                Mode = SkinWeightPaintMode.Normalize,
                Strength = 1f,
                MaximumInfluences = maximumInfluences,
                PruneThreshold = pruneThreshold,
            });
        }

        private static bool Apply(SkinWeightTable table, Mesh mesh, int vertex, int bone, float amount, SkinWeightBrushSettings settings, ISet<int> lockedBones)
        {
            var weights = table.Vertices[vertex];
            if (lockedBones != null && lockedBones.Contains(bone) && settings.Mode != SkinWeightPaintMode.Normalize) return false;
            weights.TryGetValue(bone, out float current);
            switch (settings.Mode)
            {
                case SkinWeightPaintMode.Replace: weights[bone] = Mathf.Lerp(current, 1f, amount); break;
                case SkinWeightPaintMode.Add: weights[bone] = current + amount; break;
                case SkinWeightPaintMode.Subtract: weights[bone] = Mathf.Max(0f, current - amount); break;
                case SkinWeightPaintMode.Flood: weights[bone] = Mathf.Lerp(current, 1f, amount); break;
                case SkinWeightPaintMode.Prune:
                    foreach (var key in weights.Where(pair => pair.Value < settings.PruneThreshold).Select(pair => pair.Key).ToArray()) weights.Remove(key);
                    break;
                case SkinWeightPaintMode.Smooth:
                    float average = NeighborAverage(mesh, table, vertex, bone);
                    weights[bone] = Mathf.Lerp(current, average, amount);
                    break;
                case SkinWeightPaintMode.Normalize: break;
            }
            return true;
        }

        private static float NeighborAverage(Mesh mesh, SkinWeightTable table, int vertex, int bone)
        {
            var triangles = mesh.triangles;
            float sum = 0f; int count = 0;
            for (int i = 0; i < triangles.Length; i += 3)
            {
                if (triangles[i] != vertex && triangles[i + 1] != vertex && triangles[i + 2] != vertex) continue;
                for (int j = 0; j < 3; j++)
                {
                    int neighbor = triangles[i + j];
                    if (neighbor == vertex) continue;
                    table.Vertices[neighbor].TryGetValue(bone, out float value);
                    sum += value; count++;
                }
            }
            return count > 0 ? sum / count : 0f;
        }

        private static void Mirror(IReadOnlyList<Vector3> positions, Bounds bounds, SkinWeightTable table, IReadOnlyList<int> affected, int sourceBone, int destinationBone, SkinWeightBrushSettings settings, ISet<int> lockedBones, ISet<int> lockedVertices)
        {
            float tolerance = Mathf.Max(bounds.size.magnitude * 1e-4f, 1e-5f);
            for (int i = 0; i < affected.Count; i++)
            {
                int source = affected[i];
                Vector3 expected = positions[source]; expected.x = -expected.x;
                int best = -1; float bestDistance = tolerance;
                for (int candidate = 0; candidate < positions.Count; candidate++)
                {
                    float distance = Vector3.Distance(expected, positions[candidate]);
                    if (distance <= bestDistance) { best = candidate; bestDistance = distance; }
                }
                if (best < 0 || (lockedVertices != null && lockedVertices.Contains(best))) continue;
                table.Vertices[source].TryGetValue(sourceBone, out float value);
                table.Vertices[best][destinationBone] = value;
            }
        }

        private static int MirroredBone(SkinnedMeshRenderer renderer, int boneIndex)
        {
            var bones = renderer.bones ?? Array.Empty<Transform>();
            if (boneIndex < 0 || boneIndex >= bones.Length || bones[boneIndex] == null) return boneIndex;
            string name = bones[boneIndex].name;
            string counterpart = SwapSide(name);
            if (counterpart == name) return boneIndex;
            for (int i = 0; i < bones.Length; i++) if (bones[i] != null && string.Equals(bones[i].name, counterpart, StringComparison.OrdinalIgnoreCase)) return i;
            return boneIndex;
        }

        private static string SwapSide(string value)
        {
            if (value.IndexOf("Left", StringComparison.OrdinalIgnoreCase) >= 0) return Replace(value, "Left", "Right");
            if (value.IndexOf("Right", StringComparison.OrdinalIgnoreCase) >= 0) return Replace(value, "Right", "Left");
            if (value.StartsWith("L_", StringComparison.OrdinalIgnoreCase)) return "R_" + value.Substring(2);
            if (value.StartsWith("R_", StringComparison.OrdinalIgnoreCase)) return "L_" + value.Substring(2);
            if (value.EndsWith("_L", StringComparison.OrdinalIgnoreCase)) return value.Substring(0, value.Length - 2) + "_R";
            if (value.EndsWith("_R", StringComparison.OrdinalIgnoreCase)) return value.Substring(0, value.Length - 2) + "_L";
            return value;
        }

        private static string Replace(string value, string oldValue, string newValue)
        {
            int index = value.IndexOf(oldValue, StringComparison.OrdinalIgnoreCase);
            return index < 0 ? value : value.Substring(0, index) + newValue + value.Substring(index + oldValue.Length);
        }

        private static void EnsureFallback(Dictionary<int, float> weights, int bone, ISet<int> lockedBones)
        {
            if (weights.Count > 0 && weights.Values.Sum() > 1e-12f) return;
            int fallback = bone >= 0 && (lockedBones == null || !lockedBones.Contains(bone)) ? bone : 0;
            weights.Clear(); weights[fallback] = 1f;
        }
    }
}
