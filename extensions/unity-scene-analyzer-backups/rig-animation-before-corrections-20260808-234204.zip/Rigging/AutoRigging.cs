using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using Newtonsoft.Json.Linq;
using Unity.Collections;
using UnityEditor;
using UnityEngine;
using Maicon.SceneAnalyzer.Editor.Modeling.Assets;
using Maicon.SceneAnalyzer.Modeling;

namespace Maicon.SceneAnalyzer.Editor.Modeling.Rigging
{
    public sealed class RigAutoRigProposal
    {
        public GameObject Target;
        public Mesh SourceMesh;
        public Renderer SourceRenderer;
        public string MeshHash;
        public string ProposalHash;
        public float AverageConfidence;
        public readonly List<RigAutoRigLandmark> Landmarks = new List<RigAutoRigLandmark>();
        public bool CanApply => Target != null && SourceMesh != null && AverageConfidence >= 0.55f && Landmarks.Count >= 19;

        public void Rehash()
        {
            AverageConfidence = Landmarks.Count > 0 ? Landmarks.Average(value => value.Confidence) : 0f;
            using (var sha = SHA256.Create())
            {
                var data = new StringBuilder(MeshHash);
                foreach (var value in Landmarks.OrderBy(value => value.Id)) data.Append('|').Append(value.Id).Append(':').Append(value.ParentId).Append(':')
                    .Append(value.LocalPosition.x.ToString("R", CultureInfo.InvariantCulture)).Append(',').Append(value.LocalPosition.y.ToString("R", CultureInfo.InvariantCulture)).Append(',').Append(value.LocalPosition.z.ToString("R", CultureInfo.InvariantCulture));
                ProposalHash = Hex(sha.ComputeHash(Encoding.UTF8.GetBytes(data.ToString())));
            }
        }

        internal JObject ToJson() => new JObject
        {
            ["contractVersion"] = "1.0", ["target"] = Target != null ? Target.name : string.Empty, ["meshHash"] = MeshHash,
            ["proposalHash"] = ProposalHash, ["averageConfidence"] = AverageConfidence, ["canApply"] = CanApply,
            ["landmarks"] = new JArray(Landmarks.Select(value => new JObject { ["id"] = value.Id, ["parentId"] = value.ParentId, ["localPosition"] = new JArray(value.LocalPosition.x, value.LocalPosition.y, value.LocalPosition.z), ["confidence"] = value.Confidence, ["source"] = value.Source })),
        };

        private static string Hex(byte[] bytes) { var result = new StringBuilder(bytes.Length * 2); foreach (byte value in bytes) result.Append(value.ToString("x2")); return result.ToString(); }
    }

    public sealed class RigAutoRigApplyResult
    {
        public SkinnedMeshRenderer Renderer;
        public RigAutoRigProfile Profile;
        public string MeshAssetPath;
        public int BoneCount;
        public int VertexCount;
    }

    public static class HumanoidAutoRigAnalyzer
    {
        public static RigAutoRigProposal Analyze(GameObject target)
        {
            if (target == null) throw new ArgumentNullException(nameof(target));
            ResolveMesh(target, out var renderer, out var mesh);
            var vertices = mesh.vertices; if (vertices.Length < 3) throw new InvalidOperationException("AUTO_RIG_MESH_TOO_SMALL");
            var root = target.transform; var points = vertices.Select(value => root.InverseTransformPoint(renderer.transform.TransformPoint(value))).ToArray();
            var bounds = new Bounds(points[0], Vector3.zero); for (int i = 1; i < points.Length; i++) bounds.Encapsulate(points[i]);
            if (bounds.size.y <= 1e-5f) throw new InvalidOperationException("AUTO_RIG_HEIGHT_INVALID");
            float confidence = GeometryConfidence(bounds, points); var proposal = new RigAutoRigProposal { Target = target, SourceMesh = mesh, SourceRenderer = renderer, MeshHash = MeshHash(mesh) };
            Vector3 At(float x, float y, float z) => bounds.min + Vector3.Scale(bounds.size, new Vector3(x, y, z));
            Add(proposal, "Hips", "", At(.5f, .52f, .5f), confidence);
            Add(proposal, "Spine", "Hips", At(.5f, .63f, .5f), confidence); Add(proposal, "Chest", "Spine", At(.5f, .75f, .5f), confidence);
            Add(proposal, "Neck", "Chest", At(.5f, .87f, .5f), confidence); Add(proposal, "Head", "Neck", At(.5f, .96f, .5f), confidence);
            Add(proposal, "LeftShoulder", "Chest", At(.40f, .80f, .5f), confidence); Add(proposal, "LeftUpperArm", "LeftShoulder", At(.28f, .78f, .5f), confidence); Add(proposal, "LeftLowerArm", "LeftUpperArm", At(.16f, .70f, .5f), confidence); Add(proposal, "LeftHand", "LeftLowerArm", At(.05f, .63f, .5f), confidence);
            Add(proposal, "RightShoulder", "Chest", At(.60f, .80f, .5f), confidence); Add(proposal, "RightUpperArm", "RightShoulder", At(.72f, .78f, .5f), confidence); Add(proposal, "RightLowerArm", "RightUpperArm", At(.84f, .70f, .5f), confidence); Add(proposal, "RightHand", "RightLowerArm", At(.95f, .63f, .5f), confidence);
            Add(proposal, "LeftUpperLeg", "Hips", At(.43f, .48f, .5f), confidence); Add(proposal, "LeftLowerLeg", "LeftUpperLeg", At(.43f, .25f, .5f), confidence); Add(proposal, "LeftFoot", "LeftLowerLeg", At(.43f, .04f, .62f), confidence);
            Add(proposal, "RightUpperLeg", "Hips", At(.57f, .48f, .5f), confidence); Add(proposal, "RightLowerLeg", "RightUpperLeg", At(.57f, .25f, .5f), confidence); Add(proposal, "RightFoot", "RightLowerLeg", At(.57f, .04f, .62f), confidence);
            proposal.Rehash(); RigAutoRigProposalRegistry.Store(proposal); return proposal;
        }

        internal static void ResolveMesh(GameObject target, out Renderer renderer, out Mesh mesh)
        {
            var skinned = target.GetComponentInChildren<SkinnedMeshRenderer>(true); if (skinned != null && skinned.sharedMesh != null) { renderer = skinned; mesh = skinned.sharedMesh; return; }
            var filter = target.GetComponentInChildren<MeshFilter>(true); if (filter != null && filter.sharedMesh != null && filter.GetComponent<Renderer>() != null) { renderer = filter.GetComponent<Renderer>(); mesh = filter.sharedMesh; return; }
            throw new InvalidOperationException("AUTO_RIG_MESH_NOT_FOUND");
        }

        internal static string MeshHash(Mesh mesh)
        {
            using (var sha = SHA256.Create())
            {
                var text = new StringBuilder(mesh.vertexCount * 24); foreach (var value in mesh.vertices) text.Append(value.x.ToString("R", CultureInfo.InvariantCulture)).Append(',').Append(value.y.ToString("R", CultureInfo.InvariantCulture)).Append(',').Append(value.z.ToString("R", CultureInfo.InvariantCulture)).Append(';');
                foreach (int index in mesh.triangles) text.Append(index).Append(','); return BitConverter.ToString(sha.ComputeHash(Encoding.UTF8.GetBytes(text.ToString()))).Replace("-", string.Empty).ToLowerInvariant();
            }
        }
        private static float GeometryConfidence(Bounds bounds, Vector3[] points) { float upright = bounds.size.y / Mathf.Max(1e-5f, Mathf.Max(bounds.size.x, bounds.size.z)); float symmetry = 1f - Mathf.Clamp01(Mathf.Abs(Mathf.Abs(bounds.min.x - bounds.center.x) - Mathf.Abs(bounds.max.x - bounds.center.x)) / Mathf.Max(bounds.size.x, 1e-5f)); return Mathf.Clamp01(.55f + Mathf.Clamp01(upright / 2f) * .25f + symmetry * .2f); }
        private static void Add(RigAutoRigProposal proposal, string id, string parent, Vector3 position, float confidence) => proposal.Landmarks.Add(new RigAutoRigLandmark { Id = id, ParentId = parent, LocalPosition = position, Confidence = confidence, Source = "local-heuristic" });
    }

    public static class HumanoidAutoRigService
    {
        public static RigAutoRigApplyResult Apply(RigAutoRigProposal proposal, string proposalHash, string meshHash, string outputFolder = null)
        {
            if (proposal == null) throw new ArgumentNullException(nameof(proposal)); proposal.Rehash();
            if (proposal.ProposalHash != proposalHash || proposal.MeshHash != meshHash) throw new InvalidOperationException("AUTO_RIG_HASH_MISMATCH");
            HumanoidAutoRigAnalyzer.ResolveMesh(proposal.Target, out var sourceRenderer, out var sourceMesh);
            if (HumanoidAutoRigAnalyzer.MeshHash(sourceMesh) != meshHash) throw new InvalidOperationException("AUTO_RIG_MESH_CHANGED");
            if (!proposal.CanApply) throw new InvalidOperationException("AUTO_RIG_LOW_CONFIDENCE: correct required landmarks before applying.");
            var folder = AssetModelerAssetPaths.ValidateAndEnsureFolder(string.IsNullOrWhiteSpace(outputFolder) ? "Assets/AssetModeler/Rigging/AutoRig" : outputFolder);
            var mesh = UnityEngine.Object.Instantiate(sourceMesh); mesh.name = sourceMesh.name + "_AutoRig"; string meshPath = AssetModelerAssetPaths.UniqueAssetPath(folder, mesh.name, ".asset"); AssetDatabase.CreateAsset(mesh, meshPath);
            var bones = new Dictionary<string, Transform>();
            foreach (var landmark in proposal.Landmarks)
            {
                Transform parent = !string.IsNullOrEmpty(landmark.ParentId) && bones.TryGetValue(landmark.ParentId, out var value) ? value : proposal.Target.transform;
                var bone = new GameObject(landmark.Id).transform; Undo.RegisterCreatedObjectUndo(bone.gameObject, "Create auto-rig bone"); Undo.SetTransformParent(bone, parent, "Parent auto-rig bone"); bone.position = proposal.Target.transform.TransformPoint(landmark.LocalPosition); bones[landmark.Id] = bone;
            }
            var rendererObject = sourceRenderer.gameObject; var skinned = rendererObject.GetComponent<SkinnedMeshRenderer>();
            if (skinned == null) { skinned = Undo.AddComponent<SkinnedMeshRenderer>(rendererObject); var staticRenderer = rendererObject.GetComponent<MeshRenderer>(); if (staticRenderer != null) { Undo.RecordObject(staticRenderer, "Disable static renderer"); skinned.sharedMaterials = staticRenderer.sharedMaterials; staticRenderer.enabled = false; } }
            Undo.RecordObject(skinned, "Assign auto rig"); skinned.sharedMesh = mesh; skinned.bones = proposal.Landmarks.Select(value => bones[value.Id]).ToArray(); skinned.rootBone = bones["Hips"];
            ApplyInitialWeights(proposal, skinned, mesh); mesh.bindposes = BindPoseService.Calculate(skinned); EditorUtility.SetDirty(mesh); EditorUtility.SetDirty(skinned);
            var profile = ScriptableObject.CreateInstance<RigAutoRigProfile>(); profile.name = proposal.Target.name + "_AutoRigProfile"; profile.MeshHash = meshHash; profile.ProposalHash = proposalHash; profile.AverageConfidence = proposal.AverageConfidence;
            foreach (var value in proposal.Landmarks) profile.Landmarks.Add(new RigAutoRigLandmark { Id = value.Id, ParentId = value.ParentId, LocalPosition = value.LocalPosition, Confidence = value.Confidence, Source = value.Source });
            AssetDatabase.CreateAsset(profile, AssetModelerAssetPaths.UniqueAssetPath(folder, profile.name, ".asset")); AssetDatabase.SaveAssets();
            return new RigAutoRigApplyResult { Renderer = skinned, Profile = profile, MeshAssetPath = meshPath, BoneCount = bones.Count, VertexCount = mesh.vertexCount };
        }

        private static void ApplyInitialWeights(RigAutoRigProposal proposal, SkinnedMeshRenderer renderer, Mesh mesh)
        {
            var counts = new byte[mesh.vertexCount]; var output = new List<BoneWeight1>(mesh.vertexCount * 4); var vertices = mesh.vertices;
            for (int vertex = 0; vertex < vertices.Length; vertex++)
            {
                Vector3 rootLocal = proposal.Target.transform.InverseTransformPoint(renderer.transform.TransformPoint(vertices[vertex]));
                var nearest = proposal.Landmarks.Select((value, index) => new { index, distance = (rootLocal - value.LocalPosition).sqrMagnitude }).OrderBy(value => value.distance).Take(4).ToArray();
                float sum = nearest.Sum(value => 1f / (value.distance + 1e-5f)); counts[vertex] = (byte)nearest.Length;
                foreach (var value in nearest) output.Add(new BoneWeight1 { boneIndex = value.index, weight = (1f / (value.distance + 1e-5f)) / sum });
            }
            using (var nativeCounts = new NativeArray<byte>(counts, Allocator.Temp)) using (var nativeWeights = new NativeArray<BoneWeight1>(output.ToArray(), Allocator.Temp)) mesh.SetBoneWeights(nativeCounts, nativeWeights);
        }
    }

    public static class RigAiProposalService
    {
        public static RigAutoRigProposal ImportJson(GameObject target, string json)
        {
            if (string.IsNullOrWhiteSpace(json)) throw new ArgumentException("AI_PROPOSAL_JSON_REQUIRED"); var root = JObject.Parse(json);
            if ((string)root["contractVersion"] != "1.0") throw new InvalidOperationException("AI_PROPOSAL_VERSION_UNSUPPORTED");
            var baseline = HumanoidAutoRigAnalyzer.Analyze(target); if ((string)root["meshHash"] != baseline.MeshHash) throw new InvalidOperationException("AI_PROPOSAL_MESH_HASH_MISMATCH");
            var landmarks = root["landmarks"] as JArray; if (landmarks == null) throw new InvalidOperationException("AI_PROPOSAL_LANDMARKS_REQUIRED"); baseline.Landmarks.Clear();
            foreach (var token in landmarks.OfType<JObject>())
            {
                var position = token["localPosition"] as JArray; if (position == null || position.Count != 3) throw new InvalidOperationException("AI_PROPOSAL_POSITION_INVALID");
                baseline.Landmarks.Add(new RigAutoRigLandmark { Id = (string)token["id"], ParentId = (string)token["parentId"] ?? string.Empty, LocalPosition = new Vector3((float)position[0], (float)position[1], (float)position[2]), Confidence = Mathf.Clamp01((float?)token["confidence"] ?? 0f), Source = "ai-json" });
            }
            var required = new HashSet<string>(HumanoidAutoRigAnalyzer.Analyze(target).Landmarks.Select(value => value.Id)); if (!required.SetEquals(baseline.Landmarks.Select(value => value.Id))) throw new InvalidOperationException("AI_PROPOSAL_REQUIRED_LANDMARKS_MISSING");
            baseline.Rehash(); RigAutoRigProposalRegistry.Store(baseline); return baseline;
        }
    }

    internal static class RigAutoRigProposalRegistry
    {
        private static readonly Dictionary<int, RigAutoRigProposal> Values = new Dictionary<int, RigAutoRigProposal>();
        public static void Store(RigAutoRigProposal proposal) { if (proposal?.Target != null) Values[proposal.Target.GetInstanceID()] = proposal; }
        public static RigAutoRigProposal Get(GameObject target) { Values.TryGetValue(target != null ? target.GetInstanceID() : 0, out var value); return value; }
    }

    [InitializeOnLoad]
    internal static class AutoRigPreviewController
    {
        public static RigAutoRigProposal Active { get; private set; }
        static AutoRigPreviewController() => SceneView.duringSceneGui += Draw;
        public static void Show(RigAutoRigProposal proposal) { Active = proposal; SceneView.RepaintAll(); }
        public static void Clear() { Active = null; SceneView.RepaintAll(); }
        private static void Draw(SceneView view)
        {
            if (Active?.Target == null) return; var lookup = Active.Landmarks.ToDictionary(value => value.Id);
            foreach (var value in Active.Landmarks)
            {
                Vector3 point = Active.Target.transform.TransformPoint(value.LocalPosition); Handles.color = Color.Lerp(Color.red, Color.green, value.Confidence);
                Handles.SphereHandleCap(0, point, Quaternion.identity, HandleUtility.GetHandleSize(point) * .035f, EventType.Repaint);
                if (!string.IsNullOrEmpty(value.ParentId) && lookup.TryGetValue(value.ParentId, out var parent)) Handles.DrawAAPolyLine(3f, point, Active.Target.transform.TransformPoint(parent.LocalPosition));
            }
        }
    }
}
